# Roboto fontface Bower package

A simple bower package providing the [Roboto Slab](https://www.google.com/fonts/specimen/Roboto+Slab) fontface. The font was created by [Christian Robertson](https://plus.google.com/110879635926653430880/about).

## Installing

Assuming you have [NodeJS](http://nodejs.org/) and [Bower](https://github.com/bower/bower) installed globally just open up a terminal, navigate to your projects root directory and then execute

```
$ bower install roboto-slab-fontface --save
```
