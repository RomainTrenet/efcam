Opening hours module for Drupal
===============================

This module is intended to make it fairly easy to manage opening hours
for a large number of locations.

Built for the [Ding.TING][] project, and funded by [Copenhagen Public
Libraries][KKB].

[Ding.TING]: http://ting.dk/
[KKB]: http://bibliotek.kk.dk/node/272

